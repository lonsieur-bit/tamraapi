module.exports=[76139,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_aTANARA__next-internal_server_app__global-error_page_actions_afe9820c.js.map
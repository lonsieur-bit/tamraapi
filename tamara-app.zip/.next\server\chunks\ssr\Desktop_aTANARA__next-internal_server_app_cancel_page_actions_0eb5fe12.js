module.exports=[1232,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_aTANARA__next-internal_server_app_cancel_page_actions_0eb5fe12.js.map
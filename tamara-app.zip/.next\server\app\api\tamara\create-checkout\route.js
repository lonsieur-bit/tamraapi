var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/tamara/create-checkout/route.js")
R.c("server/chunks/[root-of-the-server]__cd27b8ca._.js")
R.c("server/chunks/[root-of-the-server]__1607b1c2._.js")
R.c("server/chunks/e11b7__next-internal_server_app_api_tamara_create-checkout_route_actions_1c2aeb8e.js")
R.m(1390)
module.exports=R.m(1390).exports

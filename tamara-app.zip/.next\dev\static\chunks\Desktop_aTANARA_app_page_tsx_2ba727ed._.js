(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/26abe_98743e7e._.js",
  "static/chunks/Desktop_aTANARA_b56e0dc9._.js"
],
    source: "dynamic"
});

module.exports = [
"[project]/Desktop/aTANARA/.next-internal/server/app/api/tamara/create-checkout/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=e11b7__next-internal_server_app_api_tamara_create-checkout_route_actions_1c2aeb8e.js.map
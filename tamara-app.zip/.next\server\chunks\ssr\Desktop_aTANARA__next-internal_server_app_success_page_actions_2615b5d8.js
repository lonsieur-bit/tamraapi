module.exports=[28028,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_aTANARA__next-internal_server_app_success_page_actions_2615b5d8.js.map
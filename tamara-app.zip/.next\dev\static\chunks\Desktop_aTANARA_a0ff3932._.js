(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_32a10976._.js",
  "static/chunks/26abe_next_dist_compiled_react-dom_ed74edae._.js",
  "static/chunks/26abe_next_dist_compiled_react-server-dom-turbopack_de55b3a1._.js",
  "static/chunks/26abe_next_dist_compiled_next-devtools_index_a6a05fbc.js",
  "static/chunks/26abe_next_dist_compiled_865e5d7f._.js",
  "static/chunks/26abe_next_dist_client_32a92588._.js",
  "static/chunks/26abe_next_dist_6a6d0a7c._.js",
  "static/chunks/26abe_@swc_helpers_cjs_3cc81aea._.js"
],
    source: "entry"
});

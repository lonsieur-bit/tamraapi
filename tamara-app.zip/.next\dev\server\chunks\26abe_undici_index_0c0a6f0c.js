module.exports = [
"[project]/Desktop/aTANARA/node_modules/undici/index.js [app-route] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/26abe_undici_lib_dispatcher_ff77da11._.js",
  "server/chunks/26abe_undici_lib_llhttp_cd63d83b._.js",
  "server/chunks/26abe_undici_lib_web_b73f33c4._.js",
  "server/chunks/26abe_undici_lib_f1722097._.js",
  "server/chunks/26abe_undici_index_5e6e90fa.js",
  "server/chunks/[root-of-the-server]__1a91ec90._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/aTANARA/node_modules/undici/index.js [app-route] (ecmascript)");
    });
});
}),
];
module.exports=[41007,(e,o,d)=>{}];

//# sourceMappingURL=3d860_aTANARA__next-internal_server_app_api_tamara_webhook_route_actions_b4d770ad.js.map
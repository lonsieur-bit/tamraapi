module.exports=[4933,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_aTANARA__next-internal_server_app__not-found_page_actions_d7ba1a80.js.map
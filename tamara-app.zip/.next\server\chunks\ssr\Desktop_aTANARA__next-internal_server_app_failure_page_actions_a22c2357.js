module.exports=[69777,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_aTANARA__next-internal_server_app_failure_page_actions_a22c2357.js.map
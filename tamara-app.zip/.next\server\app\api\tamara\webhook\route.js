var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/tamara/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__fc5edce4._.js")
R.c("server/chunks/[root-of-the-server]__1607b1c2._.js")
R.c("server/chunks/3d860_aTANARA__next-internal_server_app_api_tamara_webhook_route_actions_b4d770ad.js")
R.m(44646)
module.exports=R.m(44646).exports

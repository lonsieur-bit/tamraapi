module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/Desktop/aTANARA/app/api/tamara/create-checkout/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$aTANARA$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/aTANARA/node_modules/next/server.js [app-route] (ecmascript)");
;
const TAMARA_API_KEY = process.env.TAMARA_API_KEY;
const TAMARA_MERCHANT_ID = process.env.TAMARA_MERCHANT_ID;
const TAMARA_API_URL = "https://api-sandbox.tamara.co";
async function POST(request) {
    try {
        const { customer, items, total } = await request.json();
        // Generate unique order reference
        const orderReference = `INV-${Date.now()}`;
        // Prepare Tamara checkout payload
        const tamaraPayload = {
            order_reference_id: orderReference,
            total_amount: {
                amount: total,
                currency: "SAR"
            },
            shipping_amount: {
                amount: 0,
                currency: "SAR"
            },
            tax_amount: {
                amount: 0,
                currency: "SAR"
            },
            description: "Invoice Payment",
            country_code: "SA",
            payment_type: "PAY_BY_INSTALMENTS",
            instalments: 3,
            locale: "en_US",
            platform: "web",
            is_mobile: false,
            items: items.map((item)=>({
                    reference_id: item.id,
                    type: "Physical",
                    name: item.name,
                    sku: item.id,
                    quantity: item.quantity,
                    discount_amount: {
                        amount: 0,
                        currency: "SAR"
                    },
                    tax_amount: {
                        amount: 0,
                        currency: "SAR"
                    },
                    unit_price: {
                        amount: item.price,
                        currency: "SAR"
                    },
                    total_amount: {
                        amount: item.quantity * item.price,
                        currency: "SAR"
                    }
                })),
            consumer: {
                first_name: customer.firstName,
                last_name: customer.lastName,
                phone_number: customer.phone,
                email: customer.email
            },
            billing_address: {
                first_name: customer.firstName,
                last_name: customer.lastName,
                line1: "Sample Address",
                city: "Riyadh",
                country_code: "SA",
                phone_number: customer.phone
            },
            shipping_address: {
                first_name: customer.firstName,
                last_name: customer.lastName,
                line1: "Sample Address",
                city: "Riyadh",
                country_code: "SA",
                phone_number: customer.phone
            },
            merchant_url: {
                success: `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3001"}/success`,
                failure: `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3001"}/failure`,
                cancel: `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3001"}/cancel`,
                notification: `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3001"}/api/tamara/webhook`
            }
        };
        const { request: undiciRequest } = await __turbopack_context__.A("[project]/Desktop/aTANARA/node_modules/undici/index.js [app-route] (ecmascript, async loader)");
        const response = await undiciRequest(`${TAMARA_API_URL}/checkout`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                Authorization: `Bearer ${TAMARA_API_KEY}`,
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept-Language": "en-US,en;q=0.9",
                "Accept-Encoding": "gzip, deflate, br",
                Origin: process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3001",
                Referer: `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3001"}/`,
                "Cache-Control": "no-cache",
                Pragma: "no-cache"
            },
            body: JSON.stringify(tamaraPayload)
        });
        const responseText = await response.body.text();
        let data;
        try {
            data = JSON.parse(responseText);
        } catch (e) {
            console.error("Failed to parse Tamara response - likely blocked by Cloudflare");
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$aTANARA$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "Cloudflare blocked the request",
                details: "The Tamara API is protected by Cloudflare and is blocking requests from localhost. Please deploy to production (e.g., Vercel) to use the live API.",
                cloudflare_error: true
            }, {
                status: 503
            });
        }
        if (response.statusCode !== 200 && response.statusCode !== 201) {
            console.error("Tamara API Error:", data);
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$aTANARA$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: data.message || "Failed to create checkout",
                details: data
            }, {
                status: response.statusCode
            });
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$aTANARA$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            checkout_url: data.checkout_url,
            order_id: data.order_id
        });
    } catch (error) {
        console.error("Error creating Tamara checkout:", error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$aTANARA$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Internal server error",
            details: error instanceof Error ? error.message : "Unknown error"
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__dbdfb00c._.js.map
(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__a7f5176c._.css",
  "static/chunks/26abe_60f1e565._.js"
],
    source: "dynamic"
});

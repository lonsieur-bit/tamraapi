module.exports = [
"[project]/Desktop/aTANARA/.next-internal/server/app/success/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_aTANARA__next-internal_server_app_success_page_actions_2615b5d8.js.map
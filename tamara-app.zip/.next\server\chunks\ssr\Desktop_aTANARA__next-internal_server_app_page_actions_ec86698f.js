module.exports=[74933,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_aTANARA__next-internal_server_app_page_actions_ec86698f.js.map
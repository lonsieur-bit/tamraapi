var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/tamara/create-checkout/route.js")
R.c("server/chunks/26abe_undici_index_0c0a6f0c.js")
R.c("server/chunks/26abe_next_3a82df72._.js")
R.c("server/chunks/[root-of-the-server]__dbdfb00c._.js")
R.c("server/chunks/e11b7__next-internal_server_app_api_tamara_create-checkout_route_actions_1c2aeb8e.js")
R.m("[project]/Desktop/aTANARA/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Desktop/aTANARA/app/api/tamara/create-checkout/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/Desktop/aTANARA/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Desktop/aTANARA/app/api/tamara/create-checkout/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
